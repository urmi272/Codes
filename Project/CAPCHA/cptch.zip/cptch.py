from captcha.image import ImageCaptcha
from random import randint
chars="ABCDEFGHIJKLMNOPQRSTUVWXYZ12345678900"
sen=''
for i in range(0,7):
  j=randint(0,len(chars))
  sen+=chars[j]
print(sen)
image = ImageCaptcha(width = 400,height = 220,font_sizes=(40,50,60,70,80,90,100))
image.generate(sen)
image.write(sen, 'CAPTCHA.png')


