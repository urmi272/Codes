#include <iostream>
using namespace std;

// Node structure
struct Node {
    int data;
    Node* next;
};

// Circular Linked List class
class CircularLinkedList {
private:
    Node* last; // Points to the last node in the list

public:
    // Constructor
    CircularLinkedList() {
        last = nullptr;
    }

    // Function to check if the list is empty
    bool isEmpty() {
        return last == nullptr;
    }

    // Function to insert a node at the beginning
    void insertAtBeginning(int value) {
        Node* newNode = new Node();
        newNode->data = value;

        if (isEmpty()) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
        }
    }

    // Function to insert a node at the end
    void insertAtEnd(int value) {
        Node* newNode = new Node();
        newNode->data = value;

        if (isEmpty()) {
            last = newNode;
            last->next = last;
        } else {
            newNode->next = last->next;
            last->next = newNode;
            last = newNode;
        }
    }

    // Function to delete a node from the list
    void deleteNode(int value) {
        if (isEmpty()) {
            cout << "List is empty, nothing to delete." << endl;
            return;
        }

        Node* current = last->next;
        Node* previous = last;

        // If the node to be deleted is the only node in the list
        if (current == last && current->data == value) {
            delete current;
            last = nullptr;
            return;
        }

        // Search for the node to be deleted
        do {
            if (current->data == value) {
                if (current == last) { // Deleting the last node
                    last = previous;
                }
                previous->next = current->next;
                delete current;
                return;
            }
            previous = current;
            current = current->next;
        } while (current != last->next);

        cout << "Node with value " << value << " not found." << endl;
    }

    // Function to display the nodes in the list
    void display() {
        if (isEmpty()) {
            cout << "List is empty." << endl;
            return;
        }

        Node* current = last->next;
        do {
            cout << current->data << " ";
            current = current->next;
        } while (current != last->next);

        cout << endl;
    }
};

// Main function
int main() {
    CircularLinkedList cll;

    // Insert nodes
    cll.insertAtEnd(10);
    cll.insertAtEnd(20);
    cll.insertAtEnd(30);
    cll.insertAtBeginning(5);

    // Display list
    cout << "Circular Linked List: ";
    cll.display();

    // Delete a node
    cll.deleteNode(20);
    cout << "After deleting 20: ";
    cll.display();

    // Delete another node
    cll.deleteNode(5);
    cout << "After deleting 5: ";
    cll.display();

    return 0;
}
