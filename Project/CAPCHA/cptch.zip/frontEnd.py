from tkinter import *

# Create the main window
parent = Tk()

parent.title("CAPTCHA CHECK")

parent.configure(bg='lightyellow')
# Load the image 
image = PhotoImage(file="CAPTCHA.png")

# Create a label to display the image
image_label = Label(parent, image=image)
image_label.grid(row=0, column=0, padx=40, pady=20)
Label(parent, text='Enter CAPTCHA ').grid(row=3, column=0, padx=40, pady=20)
e1 = Entry(parent)
e1.grid(row=7, column=0, padx=40, pady=20)

b1 = Button(parent, text = "reload the CAPTCHA")
b2 = Button(parent, text = "Enter ")
b1.grid(row = 10, column = 0)
b2.grid(row = 10, column = 1)
parent.mainloop()
